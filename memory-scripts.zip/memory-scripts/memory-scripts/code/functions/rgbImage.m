function [ RGB ] = rgbImage( filename )
    img = imread(filename);
    
    % Extract RED, GREEN and BLUE components from the image
    % R = 1, G = 2, B = 3
    RGB_float = img(:,:,1:3);
    RGB       = uint8(RGB_float); % float -> uint8
    
end

